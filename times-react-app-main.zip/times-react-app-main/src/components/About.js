

export default function About(){   //react component is a function

    return (
        <div>About !!</div>
    )
}