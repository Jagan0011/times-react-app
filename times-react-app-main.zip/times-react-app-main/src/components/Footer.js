

export default function Footer(){   //react component is a function

    return (
        <div>Footer</div>
    )
}