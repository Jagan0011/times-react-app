

export default function Counter(props){//stateless
    return (
        <span>{props.count +1}</span>
    )
}