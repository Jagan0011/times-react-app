

export default function Header(){   //react component is a function

    return (
        <div>Header</div>
    )
}