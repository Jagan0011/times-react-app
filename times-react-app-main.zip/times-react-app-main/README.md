1. redux, unit testing, 
Assessment : 4-5 hours 



 npm test -- --coverage